package simulacion;

public class MainPrincipal {

	public static void main(String[] args) {
        FrameSimulacion simulacion= new FrameSimulacion();
        simulacion.setVisible(true);
	}

}
